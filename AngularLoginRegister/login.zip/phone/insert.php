<?php
require '../connect.php';

 $postdata = file_get_contents("php://input");

if(isset($postdata) && !empty($postdata))
{
  $request = json_decode($postdata);

  //print_r($request);
  
  // Sanitize.
  $username = $con->real_escape_string(trim($request->username));
  $phoneno = $con->real_escape_string(trim($request->phoneno));
  

  // Store.
  $sql = "INSERT INTO `phone` VALUES (NULL,'{$username}','{$phoneno}', NULL )";

  if($con->query($sql))
  {
    http_response_code(201);
  }
  else
  {
    echo $sql;
    // http_response_code(422);
  }
}